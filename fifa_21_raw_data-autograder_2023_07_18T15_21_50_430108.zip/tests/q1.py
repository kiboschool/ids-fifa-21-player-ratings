OK_FORMAT = True

test = {   'name': 'q1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> fifa_dataset = pd.read_csv('fifa_21_raw_data.csv', engine='python')\n>>> \n>>> check_data(fifa_dataset)\nFalse", 'hidden': False, 'locked': False},
                                   {'code': ">>> fifa_dataset['Name'][0] == 'L. Messi'\n>>> \nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
