OK_FORMAT = True

test = {   'name': 'q2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> remove_duplicate(fifa_dataset)\n>>> fifa_dataset['Name'].duplicated().any() == False\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> # for name in fifa_dataset['Name'].unique():\n>>> name in fifa_dataset['Name'].unique()\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
