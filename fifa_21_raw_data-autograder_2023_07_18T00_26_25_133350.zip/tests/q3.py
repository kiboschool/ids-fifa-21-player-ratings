OK_FORMAT = True

test = {   'name': 'q3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> len(fifa_dataset["Name"].unique()) > 1000\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(fifa_dataset["Club"]) == pd.Series\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': '>>> remove_newline(fifa_dataset)\n'
                                               '>>> def is_white_spaces(dataset):\n'
                                               "...     for value in fifa_dataset['Club']:\n"
                                               "...         if value.__contains__('\\n'):\n"
                                               '...             return False\n'
                                               '...     return True\n'
                                               '>>> \n'
                                               '>>> is_white_spaces(fifa_dataset) == True\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
