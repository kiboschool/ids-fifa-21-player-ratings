OK_FORMAT = True

test = {   'name': 'q4',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(top_5_country) is dict\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(top_5_country) == 5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> top_5_country['England'] >= 1500\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
